﻿namespace HealthSystem.Damage.DamageDealer
{
    public interface IDamage
    {
        float Damage();
    }
}