﻿namespace Weapons.Projectile
{
    // 投射物接口
    public interface IProjectile
    {
    }
}