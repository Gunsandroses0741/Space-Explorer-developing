﻿using Utils;

namespace Weapons.Projectile
{
    // 普通子弹对象池
    public class NormalBulletPool : PoolBase<NormalBullet>
    {
    }
}